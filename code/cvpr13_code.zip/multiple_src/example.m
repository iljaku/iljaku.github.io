
addpath lib
addpath lib/dogma
addpath lib/util

data = load('./data/example.mat');
% training and testing data are matrix pair X,Y
% where X is a cell array, consisting of row-instance matrices,
%   each matrix for different descriptor, if you plan to use only one descriptor,
%   X still has to be a cell array with one item
% Y is a Nx1 vector of integer class IDs, e.g.
%

% hyperparameters ranges
hyper.c_val = 10.^(-4:5);
hyper.kernel_type = {'rbf'};
hyper.gamma = {2.^(-4:5)}; % {} means averaging kernels with those gammas

classifier = MulticlassRLS(struct('optimize_l_tuning', true));
tuner = HyperSearch(classifier, hyper);

disp('tuning source hyperparameters...');
hyper = tuner.search(data.source_x, data.source_y);
disp(hyper)

disp('training source...');
source_classifier = MulticlassRLS;
source_classifier.train(hyper, data.source_x, data.source_y);
disp('done.');

% MULTIpLE settings
multi_parameters.iterations = 1000;
multi_parameters.new_class_label = setdiff(data.train_y, data.source_y);
multi_parameters.priors = source_classifier; % specifying source models
hyper.beta_l = 1; % MULTIpLE hyperparameter

disp('training MULTIpLE...');
classifier = MULTIpLE(multi_parameters);
classifier.train(hyper, data.train_x, data.train_y);
rs = classifier.evaluate(data.test_x, data.test_y);
disp('done');

rs
