function parametrizations = generate_parameter_combinations(parameters)
    instance_table = {};

    for f=fieldnames(parameters)'
        f = char(f);

        instances = {};
        if iscell(parameters.(f)) || (isnumeric(parameters.(f)) && numel(parameters.(f)) > 1)
            for c=parameters.(f)
                instances{end+1} = struct(f, c);
            end
        else
            instances{end+1} = struct(f, parameters.(f));
        end

        instance_table{end+1} = instances;
    end

    parametrizations = {};

    combs=allcombs(instance_table{:});
    for i=1:size(combs, 1)
        parametrizations{end+1} = catstruct(combs{i, :});
    end
end
