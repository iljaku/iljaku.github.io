function model = k_init(ker,kerparam,C)

%K_INIT    create an empty model for training with KLS_TRAIN and RKLS_TRAIN
%MODEL = K_INIT(KERNEL_FUNCTION,KERNEL_PARAMS,C)

% This code is part of the supplementary material to the CVPR 2010 paper
% "Safety in Numbers: Learning Categories from Few Examples with Multi 
% Model Knowledge Trasfer", T. Tommasi, F. Orabona, B. Caputo.

% Copyright (C) 2009-2010, Tatiana Tommasi
%
% This program is free software: you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free Software Foundation, either version 3 of the License, or
% (at your option) any later version.
%
% This program is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
%
% You should have received a copy of the GNU General Public License
% along with this program.  If not, see <http://www.gnu.org/licenses/>.
%
% Contact the author: ttommasi [at] idiap.ch



model.K=[];
model.X=[];
model.Y=[];
model.S=[];
model.C=C;
model.ker=ker;
model.kerparam=kerparam;
model.opt=[];
model.XX=cell(4,1); %four features
