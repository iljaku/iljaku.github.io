function [kernel] = utility_predict(cue, model)

% This code is part of the supplementary material to the CVPR 2010 paper
% "Safety in Numbers: Learning Categories from Few Examples with Multi 
% Model Knowledge Trasfer", T. Tommasi, F. Orabona, B. Caputo.

% Copyright (C) 2009-2010, Tatiana Tommasi
%
% This program is free software: you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free Software Foundation, either version 3 of the License, or
% (at your option) any later version.
%
% This program is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
%
% You should have received a copy of the GNU General Public License
% along with this program.  If not, see <http://www.gnu.org/licenses/>.
%
% Contact the author: ttommasi [at] idiap.ch


for r=1:numel(cue) %num features
    nt = size(cue{r}.p_test,1);
    max_num_el=50*1024^2/8; %50 Mega of memory as maximum size for K
    step=ceil(max_num_el/numel(model.beta));
    for s=1:step:nt
        if isfield(model,'SV')
            xtest=cue{r}.p_test';
            K(:,:,r) = feval(model.ker,xtest(:,s:min(s+step-1,nt)),model.SV,model.kerparam);
        else
            nr = length(model.Y);
            xtrain=model.XX{r}';
            xtest=cue{r}.p_test';
            K(:,:,r) = feval(model.ker,[xtrain , xtest(:,s:min(s+step-1,nt))],(1:numel(s:min(s+step-1,nt)))+nr,model.S,model.kerparam);
        end
    end
end
kernel=mean(K,3);